#include <stdio.h>
#include <stdlib.h>

int main(void){
	printf("hello World\n");
	return EXIT_SUCCESS;
}
